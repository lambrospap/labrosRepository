package com.example.demo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
@Repository
public interface RestRepository extends JpaRepository<Product, Long> {
	
	  @Query("select u from Product u where u.ProductName = ?1 ")
	  Product findByEProductName(String ProductName);
	  @Query("select u from Product u where u.Price = ?1 or u.ProductName = ?2 or u.ProductCode=?3")
	  Product findCustom(String Price, String ProductName, String ProductCode);
}
