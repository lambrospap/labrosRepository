/*DROP TABLE IF EXISTS products;

CREATE TABLE products(ProductName VARCHAR(50) PRIMARY KEY,
Price VARCHAR(10),ProductCode VARCHAR(10),ProductExpirationDate  VARCHAR(50), ProductAvailabilityDate  VARCHAR(50));
*/
INSERT INTO product values('Student8.5','8.5','015','02/11/2019','01/01/2020'); 
INSERT INTO product values('Student6','6','016','03/11/2019','02/01/2020');
INSERT INTO product values('Tourist','15','017','05/11/2019','03/01/2020');
COMMIT;